---
name: Update Suggestion
about: Suggest Updates to Content
title: 'Update Suggestion: NAME OF CONTENT TO BE UPDATED'
labels: update
assignees: ''

---

**Please Describe Suggested Update:**
DESCRIBE UPDATE HERE
