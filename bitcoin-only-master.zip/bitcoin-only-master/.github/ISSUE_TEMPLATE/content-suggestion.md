---
name: Content Suggestion
about: Suggest New Content to be Added
title: 'Content Suggestion: NAME OF CONTENT TO BE ADDED'
labels: content suggestion
assignees: ''

---

1) Link to Content: PASTE URL HERE
2) Briefly Describe Content: WRITE BRIEF DESCRIPTION HERE
3) Suggested Section: SUGGEST SECTION HERE
