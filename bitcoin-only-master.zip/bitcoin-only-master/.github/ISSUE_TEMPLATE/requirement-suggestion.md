---
name: Requirement Suggestion
about: Suggest New Requirement
title: 'Requirement Suggestion: REQUIREMENT'
labels: requirement
assignees: ''

---

## Current Requirement: **REQUIREMENT HERE (E.G. HARDWARE WALLETS)**
The current listing criteria for **REQUIREMENT HERE** is:
```
**CURRENT REQUIREMENT**
```

## Future Plans: **OPTIONAL**
