---
name: Feature Suggestion
about: Suggest New Features for Bitcoin-Only.com
title: 'Feature Suggestion: FEATURE NAME'
labels: add feature
assignees: ''

---

**Please Describe Feature**
DESCRIBE FEATURE HERE
