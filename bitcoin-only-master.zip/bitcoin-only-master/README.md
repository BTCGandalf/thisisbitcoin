# Bitcoin-Only

This is the repository for [bitcoin-only.com](https://bitcoin-only.com). 

[Click Here](https://github.com/bitcoin-only/bitcoin-only/issues/new/choose) to raise an issue (e.g. to request content be added).

![](/static/og-image.png)


## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:1111
$ npm run dev

# generate static project (dist folder)
$ npm run generate
```

For detailed explanation on how things work, check out [Nuxt.js docs](https://nuxtjs.org).
